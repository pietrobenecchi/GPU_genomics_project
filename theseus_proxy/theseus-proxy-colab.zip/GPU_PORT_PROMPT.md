# Prompt: portare l'algoritmo di allineamento theseus-proxy su GPU

## Contesto già fatto (non rifarlo)

Il progetto `theseus-proxy/theseus-proxy` allinea sequenze contro un grafo (WFA su
grafo). Il porting GPU è già impostato:

- Confine host↔CUDA in `src/gpu/align_gpu.h` (solo POD), backend in
  `src/gpu/align_gpu.cu`, stub senza CUDA in `src/gpu/align_gpu_stub.cpp`.
- Il grafo è già su device in forma CSR (`src/gpu/graph_csr.{h,cpp}`,
  `upload_graph`/`readback_graph`), verificato con un kernel che lo ri-percorre.
- Entry point batch `TheseusAligner::align_batch_gpu` (un blocco per query è la
  geometria scelta), flag CLI `-b gpu`, `GpuBatchReport` per lo stato del backend.
- Capacità wavefront resa fissa e parametrica (`kProvisionalWavefrontCapacity`,
  `Scope::capacity_exceeded()`). NOTA: il bound attuale (1024) è provvisorio,
  tarato su un dataset giocattolo dove i wavefront arrivano a 4 celle. Va rifatto
  con dati reali — non fidarti del valore.
- Regressione: `-b gpu` deve restare byte-identico alla baseline
  (`baseline/sample_output.gaf`), coperto dai test ctest `gpu_sample_baseline_*`.
  Compila senza CUDA con `cmake -DBUILD_TESTING=ON` e con CUDA aggiungendo
  `-DTHESEUS_PROXY_ENABLE_CUDA=ON`. Su Colab: nvcc + T4.

## Obiettivo

Portare il calcolo dell'allineamento (`compute_new_wave` e tutto ciò che chiama)
a girare davvero sul device, un blocco per query, mantenendo output identico alla
baseline.

## Metodo obbligatorio: device-shaped su CPU prima, kernel dopo

NON scrivere direttamente un kernel. Procedi così:

1. Definisci uno `struct QueryState` con TUTTO lo stato per-query in array piatti
   POD a capacità fissa: scratchpad, scope (ring), beyond_scope (accumula per tutto
   l'allineamento), vertices_data. Zero `std::vector`/`std::set`/`std::sort`, zero
   `new`/`malloc` dopo l'inizializzazione.
2. Riscrivi l'algoritmo come funzioni libere `align_one(QueryState&, ...)` che
   operano solo su quello stato. Compila su CPU e verifica byte-identico alla
   baseline a OGNI passo (hai `diff` contro `baseline/sample_output.gaf`).
3. Solo quando è verde: annota le funzioni `__host__ __device__`, sostituisci il
   corpo di `align_batch` con il lancio `<<<num_seqs, blocco>>>`, parallelizza sui
   vertici attivi e sulle diagonali. Verifica con `compute-sanitizer` che dia
   `0 errors` e output identico.

Fai UN passo alla volta, tenendo il diff verde. Se il control flow non regge in un
kernel, è meglio scoprirlo al passo 2 che dopo settimane di appiattimento.

## Control flow (mappa)

```
align(query):  while(!_end){ if score==0 seed; compute_new_wave(); score++; new_score } backtrace
compute_new_wave: expand(); compact(); for v in active_vertices: process_vertex(v)
process_vertex: next_I; next_D; next_M; for cell in M_range: extend_diagonal
next_*: sparsify (nello scratchpad) → densify (nello scope) → forse check_and_store_jumps
extend_diagonal: LCP; check_end; forse store_M_jump
store_{M,I}_jump: invalidate; per ogni out-edge: activate_vertex + push jump + extend
```

Parallelismo: tra query (blocco), tra vertici attivi (dentro wave), tra diagonali
(dentro vertice). Lo score è sequenziale.

## I tre ostacoli noti (risolvili esplicitamente)

1. `std::sort` in `VerticesData::compact_invalid_vector` — i segmenti per vertice
   sono pochi: insertion sort o mantieni ordinato in inserimento. Niente sort
   parallelo.
2. Ricorsione in `store_I_jump` (sui vertici con `value.size()==0`) — converti in
   loop con stack esplicito a profondità limitata.
3. `activate_vertex` chiamato durante l'iterazione — i nuovi vertici entrano nella
   wave successiva (il loop cattura `num_active_vertices` all'inizio); la scrittura
   di `_m_jumps_positions[pos_score]` per wave future va sincronizzata con cura.

## Strutture da appiattire (ordine consigliato, dalla più facile)

1. `ScratchPad` — array per diagonale su `[min_diag,max_diag]` fisso + lista diags.
   Quasi già piatto; attenzione a `access_alloc` (scrive oltre size dentro
   capacity). Il pattern qui fa da modello per le altre.
2. `BeyondScope` — 4 wavefront che ACCUMULANO per tutto l'allineamento (li rilegge
   il backtrace). È il consumo di memoria per-blocco dominante: dimensiona qui.
3. `Scope` — ring di nscores wavefront, già parametrico in capacità.
4. `VerticesData` — LA PIÙ DURA: lista attivi dinamica, mappa sparsa vertex→idx,
   3× vettori di segmenti invalidi (sort/compact), 2× vettori ANNIDATI di jumps per
   score. Falla per ultima, quando il pattern è consolidato.

## Vincoli

- Ogni passo deve mantenere `diff baseline/sample_output.gaf <output>` vuoto.
- Il bound di capacità va reso esplicito e il suo superamento NON deve essere
  silenzioso (già c'è `capacity_exceeded()`; estendilo a beyond_scope/vertices_data).
- Quando arriva un dataset realistico, misura i picchi reali e ricava i bound veri
  prima di fidarti delle costanti.
