#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "theseus/alignment.h"
#include "theseus/penalties.h"
#include "theseus/theseus_aligner.h"

namespace {

struct QueryCase {
  std::string sequence;
  std::string start_node;
  int start_offset;
};

int score_alignment(theseus::Alignment alignment) {
  theseus::Penalties penalties(0, 2, 3, 1);
  return alignment.compute_affine_gap_score(penalties);
}

bool same_alignment(const theseus::Alignment &a, const theseus::Alignment &b) {
  return score_alignment(a) == score_alignment(b) &&
         a.start_offset == b.start_offset &&
         a.end_offset == b.end_offset &&
         a.query_length == b.query_length &&
         a.path == b.path &&
         a.edit_op == b.edit_op;
}

std::string graph_text() {
  return "S\t1\tACGT\n"
         "S\t2\tTGCA\n"
         "L\t1\t+\t2\t+\t0M\n";
}

std::string long_graph_text(int n) {
  std::string g = "S\t1\t";
  g.append(static_cast<size_t>(n), 'A');
  g += "\n";
  return g;
}

bool run_batch(const std::string &name, const std::vector<QueryCase> &cases,
               bool require_device, bool expect_workspace_overflow,
               int gpu_config) {
  std::stringstream graph_cpu(graph_text());
  std::stringstream graph_gpu(graph_text());
  theseus::Penalties penalties(0, 2, 3, 1);
  theseus::TheseusAligner cpu(penalties, graph_cpu);
  theseus::TheseusAligner gpu(penalties, graph_gpu);

  std::vector<std::string> seqs;
  std::vector<std::string> starts;
  std::vector<int> offsets;
  seqs.reserve(cases.size());
  starts.reserve(cases.size());
  offsets.reserve(cases.size());
  for (const QueryCase &c : cases) {
    seqs.push_back(c.sequence);
    starts.push_back(c.start_node);
    offsets.push_back(c.start_offset);
  }

  std::vector<theseus::Alignment> cpu_alignments;
  cpu_alignments.reserve(cases.size());
  for (size_t i = 0; i < cases.size(); ++i) {
    cpu_alignments.push_back(cpu.align(seqs[i], starts[i], offsets[i]));
  }

  theseus::GpuBatchReport report;
  std::vector<theseus::Alignment> gpu_alignments =
      gpu.align_batch_gpu(seqs, starts, offsets, &report, gpu_config, 128);

  bool ok = true;
  if (require_device && !report.aligned_on_device) {
    std::cerr << name << " config " << gpu_config
              << ": CUDA alignment did not run: " << report.message << "\n";
    ok = false;
  }
  if (expect_workspace_overflow && report.aligned_on_device &&
      !report.query_state_capacity_exceeded) {
    std::cerr << name << ": expected QueryState capacity overflow, got: "
              << report.message << "\n";
    ok = false;
  }
  if (gpu_alignments.size() != cpu_alignments.size()) {
    std::cerr << name << ": result count mismatch\n";
    return false;
  }
  for (size_t i = 0; i < cpu_alignments.size(); ++i) {
    if (!same_alignment(cpu_alignments[i], gpu_alignments[i])) {
      std::cerr << name << " config " << gpu_config
                << ": alignment mismatch at query " << i
                << " cpu_score=" << score_alignment(cpu_alignments[i])
                << " gpu_score=" << score_alignment(gpu_alignments[i]) << "\n";
      ok = false;
    }
  }
  std::cerr << name << " config " << gpu_config << ": " << report.message << "\n";
  return ok;
}

bool run_workspace_case(bool require_device, int gpu_config) {
  constexpr int kLong = 2050;
  std::stringstream graph_cpu(long_graph_text(kLong));
  std::stringstream graph_gpu(long_graph_text(kLong));
  theseus::Penalties penalties(0, 2, 3, 1);
  theseus::TheseusAligner cpu(penalties, graph_cpu);
  theseus::TheseusAligner gpu(penalties, graph_gpu);
  std::vector<std::string> seqs(1, std::string(kLong, 'A'));
  std::vector<std::string> starts(1, "1+");
  std::vector<int> offsets(1, 0);

  theseus::Alignment cpu_alignment = cpu.align(seqs[0], starts[0], offsets[0]);
  theseus::GpuBatchReport report;
  std::vector<theseus::Alignment> gpu_alignments =
      gpu.align_batch_gpu(seqs, starts, offsets, &report, gpu_config, 128);

  bool ok = same_alignment(cpu_alignment, gpu_alignments[0]);
  if (require_device && !report.aligned_on_device) {
    std::cerr << "workspace_overflow config " << gpu_config
              << ": CUDA alignment did not run: "
              << report.message << "\n";
    ok = false;
  }
  if (report.aligned_on_device && !report.query_state_capacity_exceeded) {
    std::cerr << "workspace_overflow config " << gpu_config
              << ": expected overflow, got: "
              << report.message << "\n";
    ok = false;
  }
  std::cerr << "workspace_overflow config " << gpu_config << ": "
            << report.message << "\n";
  return ok;
}

bool run_invalid_start_case() {
  std::stringstream graph_gpu(graph_text());
  theseus::Penalties penalties(0, 2, 3, 1);
  theseus::TheseusAligner gpu(penalties, graph_gpu);
  std::vector<std::string> seqs(1, "ACGT");
  std::vector<std::string> starts(1, "missing+");
  std::vector<int> offsets(1, 0);
  try {
    theseus::GpuBatchReport report;
    (void)gpu.align_batch_gpu(seqs, starts, offsets, &report);
  } catch (const std::out_of_range &) {
    return true;
  }
  std::cerr << "invalid_start: expected out_of_range\n";
  return false;
}

}  // namespace

int main(int argc, char **argv) {
  const bool require_device = argc > 1 && std::string(argv[1]) == "--require-device";

  std::vector<QueryCase> basic = {
      {"ACGT", "1+", 0},      // exact
      {"AGGT", "1+", 0},      // mismatch
      {"ACGTT", "1+", 0},     // insertion relative to graph
      {"ACG", "1+", 0},       // deletion relative to graph
      {"ACGTTGCA", "1+", 0},  // crosses edge 1+ -> 2+
      {"TGCA", "2+", 0},
  };

  std::vector<QueryCase> large_batch;
  large_batch.reserve(129);
  for (int i = 0; i < 129; ++i) {
    large_batch.push_back((i % 2 == 0) ? QueryCase{"ACGT", "1+", 0}
                                       : QueryCase{"TGCA", "2+", 0});
  }

  bool ok = true;
  std::cerr << "CPU baseline plus GPU Config 0 / Config 1 validation\n";
  for (int gpu_config : {0, 1}) {
    ok = run_batch("basic_cases", basic, require_device, false, gpu_config) && ok;
    ok = run_batch("batch_gt_block", large_batch, require_device, false, gpu_config) && ok;
    ok = run_workspace_case(require_device, gpu_config) && ok;
  }
  ok = run_invalid_start_case() && ok;

  return ok ? 0 : 1;
}
